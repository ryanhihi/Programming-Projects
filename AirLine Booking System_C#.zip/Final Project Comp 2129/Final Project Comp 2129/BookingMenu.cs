﻿using System;
using Microsoft.VisualBasic;
using static System.Net.Mime.MediaTypeNames;

namespace Final_Project_Comp_2129
{
	public class BookingMenu
	{
		//Private Properties
        private List<Booking> bookings;
        private CustomerMenu customerMenu;
        private FlightMenu flightMenu;

		//Constructor
        public BookingMenu(CustomerMenu customerMenu, FlightMenu flightMenu)
		{
            bookings = new List<Booking>();
            this.customerMenu = customerMenu;
            this.flightMenu = flightMenu;
        }
        // Method for displaying customer menu options
        public void DisplayBookingMenu()
        {
            Console.WriteLine("Booking Menu:");
            Console.WriteLine("1. Add Booking");
            Console.WriteLine("2. View Bookings");
            Console.WriteLine("3. Back to Main Menu");
            Console.Write("Enter your choice: ");
        }

        //Method to make booking
        public void MakeBooking()
        {
            //Display list of customers
            Console.WriteLine("List of Customers:");
            customerMenu.ViewCustomers();

            //Display list of flights
            Console.WriteLine("List of Flights:");
            flightMenu.DisplayAndRetrieveFlights();

            //The user to enter Customer ID
            Console.Write("Enter Customer ID: ");
            int customerID;
            //Read a line of text from the console.
            //Attempt to convert that text to an integer.
            // If the conversion is successful, execute the code inside the if block,
            // and store the converted integer in the customerID variable.
            if (int.TryParse(Console.ReadLine(), out customerID))
            {
                Customer bookingCustomer = customerMenu.SearchCustomerById(customerID);
                if (bookingCustomer != null)
                {
                    //Get flight number
                    Console.Write("Enter Flight Number: ");
                    string flightNumber = Console.ReadLine();
                    Flight bookedFlight = flightMenu.SearchFlightByNumber(flightNumber);
                    if (bookedFlight != null && bookedFlight.ReserveSeat())
                    {
                        Booking newBooking = new Booking(bookedFlight, bookingCustomer);
                        bookings.Add(newBooking);
                        Console.WriteLine("Booking made successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Booking failed. Either flight not found or no available seats.");
                    }
                }
                else
                {
                    Console.WriteLine($"Customer with ID {customerID} not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input for Customer ID.");
            }
        }

        //Method to view bookings
        public void ViewBookings()
        {
            Console.WriteLine("All Bookings:");
            foreach (var booking in bookings)
            {
                Console.WriteLine($"Date: {booking.DateOfBooking}");
                Console.WriteLine($"Booking Number: {booking.BookingNumber}");
                Console.WriteLine($"Customer: {booking.BookingCustomer.FirstName} {booking.BookingCustomer.LastName}");
                Console.WriteLine($"Flight Number: {booking.BookedFlight.FlightNumber}");
                Console.WriteLine();
            }
        }

        //Method to check if there are customers booked on the flight
        public bool AreCustomersBookedOnFlight(string flightNumber)
        {
            // Iterate through bookings and check if any booking is associated with the specified flight
            foreach (var booking in bookings)
            {
                if (booking.BookedFlight.FlightNumber.Equals(flightNumber, StringComparison.OrdinalIgnoreCase))
                {
                    return true; // Customers are booked on this flight
                }
            }
            return false; // No customers are booked on this flight
        }
    }
}

