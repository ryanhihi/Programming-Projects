﻿using System;
namespace Final_Project_Comp_2129
{
    public class Booking
    {
        // Properties
        public string BookingNumber { get; private set; }
        public string DateOfBooking { get; private set; }
        public Flight BookedFlight { get; private set; }
        public Customer BookingCustomer { get; private set; }

        public Booking(Flight bookedFlight, Customer bookingCustomer)
        {
            BookingNumber = GenerateBookingNumber();
            DateOfBooking = DateTime.Now.ToString(@"MM\/dd\/yyyy h\:mm tt");
            BookedFlight = bookedFlight;
            BookingCustomer = bookingCustomer;
        }

        //Method to generate Booking Number
        private string GenerateBookingNumber()
        {
            return $"{DateTime.Now:yyyyMMddHHmmss}-{new Random().Next(1000, 9999)}";
        }
    }
}

