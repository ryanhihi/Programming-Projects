﻿using System;
using System.Collections.Generic;

namespace Final_Project_Comp_2129
{
	public class CustomerMenu
	{
        //Add customers to the CustomerMenu Class
        private List<Customer> customers = new List<Customer>();

        // Method for displaying customer menu options
        public void DisplayCustomerMenu()
        {
            Console.WriteLine("Customer Menu:");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. View Customers");
            Console.WriteLine("3. Search Customer by ID");
            Console.WriteLine("4. Delete Customer");
            Console.WriteLine("5. Back to Main Menu");
            Console.Write("Enter your choice: ");
        }
        //Method to Add Customer AddCustomer

        // Need a valiadation method to prevent duplicate customers in the system
        // IsCustomerAlreadyExists Method to validate

        private bool IsCustomerAlreadyExists(string firstName, string lastName, string phone)
        {
            return customers.Exists(c =>
                c.FirstName.Equals(firstName, StringComparison.OrdinalIgnoreCase) &&
                c.LastName.Equals(lastName, StringComparison.OrdinalIgnoreCase) &&
                c.Phone.Equals(phone, StringComparison.OrdinalIgnoreCase));
        }

        //Addcustomer Method
        public void AddCustomer(string firstName, string lastName, string phone)
        {
            // Validate that there is no other customer with the same first name, last name, and phone number
            if (!IsCustomerAlreadyExists(firstName, lastName, phone))
            {
                Customer newCustomer = new Customer(firstName, lastName, phone);
                customers.Add(newCustomer);
                Console.WriteLine($"Customer {newCustomer.CustomerID} added successfully!");
            }
            else
            {
                Console.WriteLine("Customer with the same first name, last name, and phone number already exists. Cannot add duplicate customers.");
            }
        }

        // Method to handle adding a customer
        public void HandleAddCustomer()
        {
            Console.WriteLine("Enter customer details:");
            Console.Write("First Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();

            Console.Write("Phone: ");
            string phone = Console.ReadLine();

            // Call the AddCustomer method
            AddCustomer(firstName, lastName, phone);
        }
        //Method to View Customers ViewCustomers

        public void ViewCustomers()
        {
            Console.WriteLine("List of Customers:");
            foreach (var customer in customers)
            {
                Console.WriteLine($"Customer {customer.CustomerID}: {customer.FirstName} {customer.LastName} - Phone: {customer.Phone}");
            }
        }

        //Method to delete customer from the list using CustomerID
        //Ensure customer is in the Customer List
        //A customer can only be deleted if there are no bookings for that customer. 
        public void DeleteCustomer(int customerId)
        {
            Customer customerToDelete = customers.Find(c => c.CustomerID == customerId);

            if (customerToDelete != null)
            {
                // Check if the customer has bookings
                if (customerToDelete.NumberOfBookings > 0)
                {
                    Console.WriteLine($"Cannot delete customer {customerId} because there are bookings associated with this customer.");
                }
                else
                {
                    customers.Remove(customerToDelete);
                    Console.WriteLine($"Customer {customerId} deleted successfully!");
                }
            }
            else
            {
                Console.WriteLine($"Customer with ID {customerId} not found. Cannot delete.");
            }
        }

        //Additional Method to search customer by CustomerID
        public Customer SearchCustomerById(int customerId)
        {
            Customer foundCustomer = customers.Find(c => c.CustomerID == customerId);

            if (foundCustomer != null)
            {
                Console.WriteLine($"Customer {customerId} found:");
                Console.WriteLine($"Name: {foundCustomer.FirstName} {foundCustomer.LastName}");
                Console.WriteLine($"Phone: {foundCustomer.Phone}");
                Console.WriteLine($"Total Flights Booked: {foundCustomer.NumberOfBookings}");
            }
            else
            {
                Console.WriteLine($"Customer with ID {customerId} not found.");
            }
            return foundCustomer;
        }



    }
}

