﻿using System;

namespace Final_Project_Comp_2129
{
    public class FlightMenu
    {
        //Properties
        internal Flight[] flights;
        private BookingMenu bookingMenu; //In order to access the AreCustomersBookedOnFlight() Method from BookingMenu Class
        
        // Method for displaying customer menu options
        public void DisplayFlightMenu()
        {
            Console.WriteLine("Flight Menu:");
            Console.WriteLine("1. Add Flight");
            Console.WriteLine("2. View Flights");
            Console.WriteLine("3. View a particular Flight");
            Console.WriteLine("4. Delete Flight");
            Console.WriteLine("5. Back to Main Menu");
            Console.Write("Enter your choice: ");
        }
        // Method to ensure the flight is unique in the system IsFlightNumberUnique
        private static bool IsFlightNumberUnique(Flight[] flights, string flightNumber)
        {
            foreach (var flight in flights)
            {
                if (flight?.FlightNumber.Equals(flightNumber, StringComparison.OrdinalIgnoreCase) == true)
                {
                    return false; // Flight number already exists
                }
            }
            return true; // Flight number is unique
        }

        // Method to add a flight into the system & using the IsFlightNumberUnique method to prevent duplicate

        public Flight[] AddFlight(string flightNumber, string departureCity, string arrivalCity, DateTime departureTime, DateTime arrivalTime, int availableSeats)
        {
            // Validate that the flight number is unique
            if (IsFlightNumberUnique(flights, flightNumber))
            {
                Flight newFlight = new Flight(flightNumber, departureCity, arrivalCity, departureTime, arrivalTime, availableSeats);
                Console.WriteLine("Flight added successfully!");

                // Create a new array to hold the existing flights plus the new flight
                Flight[] updatedFlights = new Flight[flights.Length + 1];

                // Copy existing flights to the new array
                Array.Copy(flights, updatedFlights, flights.Length);

                // Add the new flight to the end of the new array
                updatedFlights[flights.Length] = newFlight;

                // Return the updated array
                return updatedFlights;
            }
            else
            {
                Console.WriteLine($"Flight with number {flightNumber} already exists. Cannot add duplicate flights.");
                return flights; // Return the original array
            }
        }

        //Method to display all flight

        public void DisplayAndRetrieveFlights()
        {
            Console.WriteLine("All Flights:");

            // Implement logic to retrieve existing flights directly within the method
            Flight[] existingFlights = RetrieveExistingFlights();

            foreach (var flight in existingFlights)
            {
                if (flight != null)
                {
                    flight.DisplayFlightInfo();
                }
            }
        }

        // Method to
        private Flight[] RetrieveExistingFlights()
        {
            //The data sources havent been constructed so I use sample data
            // Using sample Data
            Flight[] flights = new Flight[]
            {
        new Flight("FL001", "CityA", "CityB", DateTime.Now, DateTime.Now.AddHours(2), 100),
        new Flight("FL002", "CityC", "CityD", DateTime.Now.AddHours(3), DateTime.Now.AddHours(5), 120),
        new Flight("FL003", "CityE", "CityF", DateTime.Now.AddHours(6), DateTime.Now.AddHours(8), 80),
        new Flight("FL004", "CityG", "CityH", DateTime.Now.AddHours(9), DateTime.Now.AddHours(11), 150),
        new Flight("FL005", "CityI", "CityJ", DateTime.Now.AddHours(12), DateTime.Now.AddHours(14), 200),
        new Flight("FL006", "CityK", "CityL", DateTime.Now.AddHours(15), DateTime.Now.AddHours(17), 90),
        new Flight("FL007", "CityM", "CityN", DateTime.Now.AddHours(18), DateTime.Now.AddHours(20), 110),
        new Flight("FL008", "CityO", "CityP", DateTime.Now.AddHours(21), DateTime.Now.AddHours(23), 130),
        new Flight("FL009", "CityQ", "CityR", DateTime.Now.AddHours(24), DateTime.Now.AddHours(26), 180),
        new Flight("FL010", "CityS", "CityT", DateTime.Now.AddHours(27), DateTime.Now.AddHours(29), 70),

            };

            return flights;
        }
        //Method to search a flight by number

        public Flight SearchFlightByNumber(string flightNumber)
        {
            foreach (var flight in flights)
            {
                if (flight?.FlightNumber.Equals(flightNumber, StringComparison.OrdinalIgnoreCase) == true)
                {
                    return flight;
                }
            }
            return null; // Flight not found
        }

        // Method to remove a flight from the system RemoveFlight
        //Additional logic: A flight can only be deleted if there are no customers booked on the flight.
        //Need to construct a method to check if there is customer booked on the flight which is constructed on BookingMenu class

        public void RemoveFlight(string flightNumber)
        {
            // Check if there are customers booked on the flight using the BookingMenu reference
            if (bookingMenu.AreCustomersBookedOnFlight(flightNumber))
            {
                Console.WriteLine($"Cannot remove the flight {flightNumber}. Customers are booked on this flight.");
                return;
            }

            for (int i = 0; i < flights.Length; i++)
            {
                if (flights[i]?.FlightNumber.Equals(flightNumber, StringComparison.OrdinalIgnoreCase) == true)
                {
                    Console.WriteLine($"Removing flight {flightNumber}:");
                    flights[i] = null; // Remove the flight from the array
                    return;
                }
            }

            Console.WriteLine($"Flight {flightNumber} not found.");
        }

        
    }
}
