﻿using System;
using System.Numerics;
using System.Collections.Generic;

namespace Final_Project_Comp_2129
{
    public class Customer
    {
        // Properties
        public int CustomerID { get; private set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public int NumberOfBookings { get; private set; }

        //Assigning unique customer ID
        // Static counter for assigning unique customer IDs
        private static int nextCustomerId = 1;

        // Constructor
        public Customer(string firstName, string lastName, string phone)
        {
            CustomerID = nextCustomerId++;
            FirstName = firstName;
            LastName = lastName;
            Phone = phone;
            NumberOfBookings = 0; //NumberOfBookings to display on customer profile and Booking Method
        }
    }
}
        