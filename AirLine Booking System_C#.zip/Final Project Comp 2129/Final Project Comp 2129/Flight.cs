﻿using System;
using System.IO;

namespace Final_Project_Comp_2129
{
    public class Flight
    {
        // Properties
        public string FlightNumber { get; set; }
        public string DepartureCity { get; set; }
        public string ArrivalCity { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public int AvailableSeats { get; set; }

        // Constructor
        public Flight(string flightNumber, string departureCity, string arrivalCity, DateTime departureTime, DateTime arrivalTime, int availableSeats)
        {
            FlightNumber = flightNumber;
            DepartureCity = departureCity;
            ArrivalCity = arrivalCity;
            DepartureTime = departureTime;
            ArrivalTime = arrivalTime;
            AvailableSeats = availableSeats;
        }

        // Method to display flight information
        public void DisplayFlightInfo()
        {
            Console.WriteLine($"Flight: {FlightNumber}");
            Console.WriteLine($"Departure: {DepartureCity} - {DepartureTime}");
            Console.WriteLine($"Arrival: {ArrivalCity} - {ArrivalTime}");
            Console.WriteLine($"Available Seats: {AvailableSeats}");
            Console.WriteLine();
        }

        //Method to reservve Seat
        public bool ReserveSeat()
        {
            if (AvailableSeats > 0)
            {
                AvailableSeats--;
                Console.WriteLine("Seat reserved successfully!");
                return true;
            }
            else
            {
                Console.WriteLine("Sorry, no available seats for this flight.");
                return false;
            }
        }

    }
}
