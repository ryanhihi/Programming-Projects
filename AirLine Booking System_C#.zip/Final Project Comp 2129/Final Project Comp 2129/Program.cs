﻿//Final Project Advanced Object Oriented Programming
//Ryan Tran
//Student number: 101460443

using System;

namespace Final_Project_Comp_2129
{
    class Program
    {
        static void Main(string[] args)
        {
            AirLineCoordinator airlineCoordinator = new AirLineCoordinator("RyanABC Airlines");
            airlineCoordinator.StartAirlineSystem();

            
        }
    }
}
