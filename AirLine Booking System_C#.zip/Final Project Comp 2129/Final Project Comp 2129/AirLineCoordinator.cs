﻿using System;

namespace Final_Project_Comp_2129
{
    public class AirLineCoordinator
    {
        public string AirlineName;
        private CustomerMenu customerMenu;
        private FlightMenu flightMenu;
        private BookingMenu bookingMenu;

        // Constructor to initialize components
        public AirLineCoordinator(string airlineName)
        {
            AirlineName = airlineName;
            customerMenu = new CustomerMenu();
            flightMenu = new FlightMenu();
            bookingMenu = new BookingMenu(customerMenu, flightMenu);
        }
        // Getter to access CustomerMenu
        public CustomerMenu GetCustomerMenu()
        {
            return customerMenu;
        }

        // Getter to access FlightMenu
        public FlightMenu GetFlightMenu()
        {
            return flightMenu;
        }

        // Getter to access BookingMenu
        public BookingMenu GetBookingMenu()
        {
            return bookingMenu;
        }
        // Method to start the airline system
        public void StartAirlineSystem()
        {
            Console.WriteLine($"{AirlineName} Limited.");
            Console.WriteLine(" ");
            Console.WriteLine($"Welcome to {AirlineName} Airline Reservation System!");
            Console.WriteLine(" ");

            int mainChoice;

            do
            {
                Console.WriteLine("Please select a choice from the menu below");
                Console.WriteLine(" ");
                Console.WriteLine("1. CUSTOMER MENU");
                Console.WriteLine("2. FLIGHT MENU");
                Console.WriteLine("3. BOOKING MENU ");
                Console.WriteLine("4. EXIT ");

                Console.Write("Enter your choice: ");
                string userInput = Console.ReadLine();

                if (int.TryParse(userInput, out mainChoice))
                {
                    switch (mainChoice)
                    {
                        case 1:
                            // Customer Menu
                            HandleCustomerMenu();
                            break;
                        case 2:
                            // Flight Menu
                            HandleFlightMenu();
                            break;
                        case 3:
                            // Booking Menu
                            HandleBookingMenu();
                            break;
                        case 4:
                            // Exit
                            Console.WriteLine("Exiting program, press Enter. Goodbye!");
                            Console.ReadLine();
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please enter a valid option.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                }
            } while (mainChoice != 4);
        }




        // Method to handle the customer menu

        public void HandleCustomerMenu()
        {
            var customerMenu = GetCustomerMenu();
            int customerChoice;

            do
            {
                customerMenu.DisplayCustomerMenu();

                // Read and validate the user's choice
                while (!int.TryParse(Console.ReadLine(), out customerChoice) || customerChoice < 1 || customerChoice > 5)
                {
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                    customerMenu.DisplayCustomerMenu();
                }

                // Handle the user's choice
                switch (customerChoice)
                {
                    case 1:
                        // Add Customer
                        customerMenu.HandleAddCustomer();
                        break;
                    case 2:
                        // View Customers
                        customerMenu.ViewCustomers();
                        break;
                    case 3:
                        // Search customer by ID
                        Console.Write("Enter Customer ID to search: ");
                        if (int.TryParse(Console.ReadLine(), out int customerId))
                        {
                            var foundCustomer = customerMenu.SearchCustomerById(customerId);
                            if (foundCustomer != null)
                            {
                                Console.WriteLine($"Customer found: {foundCustomer.FirstName} {foundCustomer.LastName}");
                                // Additional information or actions based on the found customer
                            }
                            else
                            {
                                Console.WriteLine($"Customer with ID {customerId} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for Customer ID.");
                        }
                        break;
                    case 4:
                        // Delete Customer
                        Console.Write("Enter Customer ID to delete: ");
                        if (int.TryParse(Console.ReadLine(), out int customerIdToDelete))
                        {
                            customerMenu.DeleteCustomer(customerIdToDelete);
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for Customer ID.");
                        }
                        break;
                    case 5:
                        // Back to Main Menu
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid option.");
                        break;
                }
            } while (customerChoice != 5);
        }


        //Method to handle Flight Menu
        public void HandleFlightMenu()
        {
            var flightMenu = GetFlightMenu();
            int userChoice;

            do
            {
                flightMenu.DisplayFlightMenu();

                // Read and validate the user's choice
                while (!int.TryParse(Console.ReadLine(), out userChoice) || userChoice < 1 || userChoice > 5)
                {
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                    flightMenu.DisplayFlightMenu();
                }

                // Handle the user's choice
                switch (userChoice)
                {
                    case 1:
                        // Add Flight
                        AddFlight(flightMenu);
                        break;
                    case 2:
                        // View Flights
                        flightMenu.DisplayAndRetrieveFlights();
                        break;

                    case 3:
                        //View a particular Flight
                        string searchFlightNumber = Console.ReadLine();
                        Flight foundFlight = flightMenu.SearchFlightByNumber(searchFlightNumber);

                        if (foundFlight != null)
                        {
                            Console.WriteLine($"Flight found: {foundFlight.FlightNumber} - {foundFlight.DepartureCity} to {foundFlight.ArrivalCity}");
                           
                        }
                        else
                        {
                            Console.WriteLine($"Flight with number {searchFlightNumber} not found.");
                        }
                        break;
                        
                    case 4:
                        //Delete Flight
                        Console.Write("Enter Flight Number to remove: ");
                        string removeFlightNumber = Console.ReadLine();
                        flightMenu.RemoveFlight(removeFlightNumber);
                        break;
                        
                  
                    case 5:
                        // Back to Main Menu
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid option.");
                        break;
                }
            } while (userChoice != 5);
        }

        // Method to add flight, calling the AddFlight method from FlightMenu
        private void AddFlight(FlightMenu flightMenu)
        {
            // Get flight data from the user
            Console.Write("Enter Flight Number: ");
            string flightNumber = Console.ReadLine();

            Console.Write("Enter Departure City: ");
            string departureCity = Console.ReadLine();

            Console.Write("Enter Arrival City: ");
            string arrivalCity = Console.ReadLine();

            Console.Write("Enter Departure Time (yyyy-MM-dd HH:mm): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime departureTime))
            {
                Console.Write("Enter Arrival Time (yyyy-MM-dd HH:mm): ");
                if (DateTime.TryParse(Console.ReadLine(), out DateTime arrivalTime))
                {
                    Console.Write("Enter Available Seats: ");
                    if (int.TryParse(Console.ReadLine(), out int availableSeats))
                    {
                        // Call the AddFlight method from FlightMenu
                        flightMenu.flights = flightMenu.AddFlight(flightNumber, departureCity, arrivalCity, departureTime, arrivalTime, availableSeats);
                    }
                    else
                    {
                        Console.WriteLine("Invalid input for Available Seats.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input for Arrival Time.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input for Departure Time.");
            }
        }
        //Method to handle Booking Menu

        public void HandleBookingMenu()
        {
            var bookingMenu = GetBookingMenu();
            int bookingchoice;

            do
            {
                bookingMenu.DisplayBookingMenu();

                // Read and validate the user's choice
                while (!int.TryParse(Console.ReadLine(), out bookingchoice) || bookingchoice < 1 || bookingchoice > 3)
                {
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                    bookingMenu.DisplayBookingMenu();
                }

                // Handle the user's choice
                switch (bookingchoice)
                {
                    case 1:
                        // Add Booking
                        bookingMenu.MakeBooking();
                        break;
                    case 2:
                        // View Bookings
                        bookingMenu.ViewBookings();
                        break;
                    case 3:
                        // Back to Main Menu
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid option.");
                        break;
                }
            } while (bookingchoice != 3);
        }
    }
}