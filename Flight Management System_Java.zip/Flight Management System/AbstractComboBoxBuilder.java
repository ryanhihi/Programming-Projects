package com.example.finalprojectjavasem3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.util.StringConverter;

import java.lang.reflect.Method;
import java.util.List;

public abstract class AbstractComboBoxBuilder<T> {


    public ComboBox<T> createObjectComboBox(List<T> items) {
        ObservableList<T> options = FXCollections.observableArrayList(items);
        ComboBox<T> comboBox = new ComboBox<>(options);

        // Customize the cell factory to display only a part of the object in the ComboBox
        comboBox.setCellFactory(param -> new ListCell<T>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    // Customize this part based on the type of object
                    setText(getStringRepresentation(item));
                }
            }
        });

        // Customize the string converter for correct conversion
        comboBox.setConverter(new StringConverter<T>() {
            @Override
            public String toString(T object) {
                return object == null ? "" : getStringRepresentation(object);
            }

            @Override
            public T fromString(String string) {
                // Implement this method if needed
                return null;
            }
        });

        return comboBox;
    }

    // Abstract method to get a string representation of the object
    protected abstract String getStringRepresentation(T object);


}

