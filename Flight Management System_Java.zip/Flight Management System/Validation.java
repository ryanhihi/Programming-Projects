/***********************************************
 *
 *   Airline Flight Management System
 *   Validation Class
 *
 *   COMP2130
 *   Nicole Milmine
 *   101462077
 *
 ************************************************/
// Import necessary libraries
package com.example.finalprojectjavasem3;

import java.util.*; // for scanner

// Main validation class
public class Validation {

    // Checks the given input to make sure the users input
    // is within the given guidelines
    public static int validateInt(int min, int max){
        Scanner reader = new Scanner(System.in);
        int read;

        do {
            while(!reader.hasNextInt()) { // checks that the next provided input is a number
                System.out.print("Enter a valid number ");
                reader.next(); // ensures it is not an infinite loop
            }

            read = reader.nextInt(); // reads the next int value
            if (min <= read && read <= max) // validates within given parameters
                return read;
            else
                System.out.print("Enter a valid number ");
        } while (true); // no reason to break loop unless a value is returned
    }

    // Validates an input string to check that it is not JUST numbers.
    // Numbers are allowed because some cities and names have them
    public static String validateString(){
        Scanner reader = new Scanner(System.in);
        String read;
        boolean numeric ;

        do {
            numeric = true;
            read=reader.next();

            try { // checks if the input can be a double type
                Double num = Double.parseDouble(read);
            } catch (NumberFormatException e) {
                numeric = false; // if it can NOT be a double
            }

            if(!numeric) // return value when the variable is NOT a double
                return read;
            else
                System.out.println("Enter a valid option ");

        }while (true);
    }

    // Specifically validates the flight Fare
    // The flight fare is going to be a numeric value
    public static String validateFare(){
        Scanner reader = new Scanner(System.in);
        double read;

        do {
            while(!reader.hasNextDouble()) { // checks if next input is of double type
                System.out.print("Enter a valid value ");
                reader.next(); // ensures it's not an infinite loop
            }

            read = reader.nextDouble();
            if (0 <= read && read <= 9999) // relatively realistic numbers
                return Double.toString(read); // because the variable you want is a string
            else
                System.out.print("Enter a valid value ");
        } while (true);
    }

    // Prompt the user to hit ENTER to continue
    // Gives user a chance to read output before moving on
    public static void promptEnterKey(){
        System.out.print("Press \"ENTER\" to continue...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }
    //Validate for the input of updateFlight method input
    public static String validateCityName() {
        Scanner reader = new Scanner(System.in);
        String read;

        do {
            read = reader.next();
            if (read.matches("[a-zA-Z]+")) { // Check if the input contains only letters
                return read;
            } else {
                System.out.println("Enter a valid city name");
            }
        } while (true);
    }
    // Code taken from stackoverflow
    // https://stackoverflow.com/questions/26184409/java-console-prompt-for-enter-input-before-moving-on
    // The first answer
}
