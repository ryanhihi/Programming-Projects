package com.example.finalprojectjavasem3;

//import packages
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Scanner;


// Passenger class
    public class Passenger {
        // Initialize variables
        private String passportID;
        private String firstName;
        private String lastName;
        private int age;



        // Constructor
        public Passenger(String passportID, String firstName, String lastName, int age) {
            this.passportID = passportID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
        }

        // Getters


        public String getPassportID() {
            return passportID;
        }

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public int getAge() {
            return age;
        }

        // Method to Add Passenger into the System
        //First need to check if a passenger already exists in the system
        private static boolean isPassengerAlreadyExists(List<Passenger> passengers, String  passportId) {
            return passengers.stream()
                    .anyMatch(passenger -> passenger.getPassportID().equals(passportId));
        }

        // Method to add a new passenger into the system using isPassengerAlreadyExists method to prevent duplicate
        public static String addPassenger(List<Passenger> passengers, String passportId, String firstName, String lastName, int age) {
            try {
                if (!isPassengerAlreadyExists(passengers, passportId)) {
                    Passenger newPassenger = new Passenger(passportId, firstName, lastName, age);
                    passengers.add(newPassenger);
                    return  ("Passenger added successfully!");
                } else {
                    throw new DuplicatePassengerException(firstName, lastName, passportId);
                }
            } catch (DuplicatePassengerException e) {
                return e.getMessage();
            }
        }

        public String updateInfo(){ // prints the object info on the screen
            return ("Passport ID: " + passportID +
                    "\nFirst name: "   + firstName +
                    "\nLast name: "      + lastName +
                    "\nAge: "            + age );
        }

        public static Scene add(List<Passenger> passengers, Stage primaryStage, Scene previousScene){
            final Scene[] scene = new Scene[1];

            // Labels
            Label title = new Label("Add Passenger");
            title.setStyle("-fx-font-size: 26;");
            Label passLabel = new Label("Passport ID:");
            passLabel.setMinSize(140, 30);
            Label fNameLabel = new Label("First Name:");
            fNameLabel.setMinSize(140, 30);
            Label lNameLabel = new Label("Last Name:");
            lNameLabel.setMinSize(140, 30);
            Label ageLabel = new Label("Age:");
            ageLabel.setMinSize(140, 30);
            final Label errorLabel = new Label();
            errorLabel.setMinSize(140, 30);

            // Text Fields
            TextField passTF = new TextField();
            passTF.setMinSize(140,30);
            TextField fNameTF = new TextField();
            fNameTF.setMinSize(140, 30);
            TextField lNameTF = new TextField();
            lNameTF.setMinSize(140, 30);
            Spinner<Integer> ageSpinner = new Spinner<>(1, 150, 20);
            ageSpinner.setEditable(true);

            HBox passHbox = new HBox(0, passLabel, passTF);
            passHbox.setStyle("-fx-alignment: center;");
            HBox fNameHbox = new HBox(0, fNameLabel, fNameTF);
            fNameHbox.setStyle("-fx-alignment: center;");
            HBox lNameHbox = new HBox(0, lNameLabel, lNameTF);
            lNameHbox.setStyle("-fx-alignment: center;");
            HBox ageHbox   = new HBox(0, ageLabel, ageSpinner);
            ageHbox.setStyle("-fx-alignment: center;");

            // Submit button
            Button submit = new Button("Submit");
            submit.setMinSize(80, 30);
            submit.setOnAction(e -> {
                // age is a number
                ageSpinner.getEditor().textProperty().addListener((observable, oldValue, newValue) -> {
                    try {
                        // Try parsing the entered text as an integer
                        Integer.parseInt(newValue);
                    } catch (NumberFormatException error) {
                        // If parsing fails, set the old value
                        ageSpinner.getEditor().setText(oldValue);
                    }
                });

                if(!passTF.getText().isEmpty() && !fNameLabel.getText().isEmpty() && !lNameLabel.getText().isEmpty() && !ageSpinner.getValue().describeConstable().isEmpty()) {
                    errorLabel.setText(addPassenger(
                            passengers,
                            passTF.getText(),
                            fNameTF.getText(),
                            lNameTF.getText(),
                            ageSpinner.getValue()
                    ));

                    passTF.clear();
                    fNameTF.clear();
                    lNameTF.clear();
                }
                else
                    errorLabel.setText("Please fill in all areas.");
            });

            // Exit button
            Button exit   = new Button("Exit");
            exit.setMinSize(80, 30);
            exit.setOnAction(e -> primaryStage.setScene(previousScene));


            HBox bottom = new HBox(10, submit, exit);
            bottom.setStyle("-fx-alignment: center;");
            VBox vBox = new VBox(10, title, passHbox, fNameHbox, lNameHbox, ageHbox, errorLabel, bottom);
            vBox.setStyle("-fx-alignment: center;");
            scene[0] = new Scene(vBox, 500, 450);

            return scene[0];
        }

        public String toString(){ // returns a string value of the object
            return "ID: " + passportID +", Name: " + firstName + ", " + lastName + ", " + age;
        }

        // Method to remove passenger from the system using passportId parameter
        // Use findPassenger method to support
        private static String deletePassenger(List<Passenger> passengers, List<Reservation> reservations, String passportId) {
            try {
                Passenger passengerToDelete = findPassenger(passengers, passportId);

                if (passengerToDelete != null) {
                    if (booked(reservations, passportId)) { // check against reservations
                        return  ("Cannot delete passenger with passport ID " + passportId + "\nbecause there are bookings associated with this passenger.");
                    } else {
                        passengers.remove(passengerToDelete);
                        return ("Passenger with passport ID " + passportId + "\ndeleted from the system successfully!");
                    }
                } else {
                    throw new PassengerNotFoundException(passportId);
                }
            } catch (PassengerNotFoundException e) {
                return e.getMessage();
            }
        }

        public static Scene remove(List<Passenger> passengers, List<Reservation> reservations, Stage primaryStage, Scene previousScene){
            final Scene[] scene = new Scene[1];
            final Passenger[] selected = new Passenger[1];

            // Labels
            Label title = new Label("Delete Passenger");
            title.setStyle("-fx-font-size: 26;");
            Label delPass = new Label("Choose Passenger");
            Label errorLabel = new Label();
            errorLabel. setMinSize(140, 30);

            AbstractComboBoxBuilder<Passenger> builder = new AbstractComboBoxBuilder<Passenger>() {
                @Override
                protected String getStringRepresentation(Passenger object) {
                    return object == null ? "" : object.toString();
                }
            };
            ComboBox<Passenger> comboBox = builder.createObjectComboBox(passengers);

            HBox passHbox = new HBox(0, delPass, comboBox);
            passHbox.setStyle("-fx-alignment: center;");

            // Submit button
            Button submit = new Button("Submit");
            submit.setMinSize(80, 30);
            submit.setOnAction(e -> {
                selected[0] = comboBox.getSelectionModel().getSelectedItem();
                if (selected[0] != null){
                    errorLabel.setText("");
                    errorLabel.setText(deletePassenger(passengers, reservations, selected[0].getPassportID()));

                    if (errorLabel.equals("Passenger with passport ID " + selected[0].getPassportID() + " deleted from the system successfully!")) {
                        comboBox.getSelectionModel().clearSelection();
                        comboBox.getItems().setAll(passengers);
                    }
                } else
                    errorLabel.setText("Please choose a passenger");
             });

            // Exit button
            Button exit = new Button("Exit");
            exit.setMinSize(80, 30);
            exit.setOnAction(e -> primaryStage.setScene(previousScene));

            HBox bottom = new HBox(10, submit, exit);
            bottom.setStyle("-fx-alignment: center;");
            VBox vBox = new VBox(10, title, passHbox, errorLabel, bottom);
            vBox.setStyle("-fx-alignment: center;");
            scene[0] = new Scene(vBox, 500, 450);

            return scene[0];
        }

        private static boolean booked(List<Reservation> reservations, String passengerID){
            for (Reservation reservation : reservations){
                if (reservation.getPassengerID().equals(passengerID))
                    return true;
            }
            return false;
        }

        private static Passenger findPassenger(List<Passenger> passengers, String passportId) {
            for (Passenger p : passengers) {
                if (p.passportID.equals(passportId)) {
                    return p;
                }
            }
            return null;
        }

        public static Scene display(List<Passenger> passengers, Stage primaryStage, Scene previousScene){
            Passenger[] selected = new Passenger[1];
            Scene[] scene = new Scene[1];

            // Labels
            Label title = new Label("Display Reservation");
            title.setStyle("-fx-font-size: 26;");
            Label passLabel = new Label("Choose Reservation: ");
            passLabel.setMinSize(140, 30);
            Label info = new Label(passengers.get(0).updateInfo());

            //Combo box
            AbstractComboBoxBuilder<Passenger> builder = new AbstractComboBoxBuilder<Passenger>() {
                @Override
                protected String getStringRepresentation(Passenger object) {
                    return object == null ? "" : object.toString();
                }
            };
            ComboBox<Passenger> comboBox = builder.createObjectComboBox(passengers);
            comboBox.getSelectionModel().selectFirst();
            comboBox.setOnAction(e -> {
                selected[0] = comboBox.getSelectionModel().getSelectedItem();
                if (selected[0] != null){
                    info.setText(selected[0].updateInfo());
                }
            });

            // Next
            Button nextButton = new Button("Next");
            nextButton.setMinSize(80, 30);
            nextButton.setOnAction(e -> {
                comboBox.getSelectionModel().select(
                        comboBox.getSelectionModel().getSelectedIndex()
                        + 1
                        + comboBox.getItems().size()
                        % comboBox.getItems().size()
                );
                selected[0] = comboBox.getSelectionModel().getSelectedItem();
                if (selected[0] != null){
                    info.setText(selected[0].updateInfo());
                }
            });

            // Previous
            Button prevButton = new Button("Previous");
            prevButton.setMinSize(80, 30);
            prevButton.setOnAction(e -> {
                if((comboBox.getSelectionModel().getSelectedIndex() - 1 + comboBox.getItems().size() % comboBox.getItems().size()
                    ) >= 0){
                    comboBox.getSelectionModel().select(
                            comboBox.getSelectionModel().getSelectedIndex()
                                    - 1
                                    + comboBox.getItems().size()
                                    % comboBox.getItems().size()
                    );
                    selected[0] = comboBox.getSelectionModel().getSelectedItem();
                    info.setText(selected[0].updateInfo());
                }
            });

            // Exit
            Button exit = new Button("Exit");
            exit.setMinSize(80, 30);
            exit.setOnAction(e -> primaryStage.setScene(previousScene));

            HBox hBox = new HBox(10, prevButton, exit, nextButton);
            hBox.setStyle("-fx-alignment: center;");
            VBox vBox = new VBox(10, title, comboBox, info, hBox);
            vBox.setStyle("-fx-alignment: center;");
            scene[0] = new Scene(vBox, 500, 450);

            return scene[0];
        }
    }

    class PassengerNotFoundException extends Exception {
        public PassengerNotFoundException(String passportId) {
            super("Passenger with passport ID " + passportId + " not found.");
        }
    }


    class DuplicatePassengerException extends Exception {
        public DuplicatePassengerException(String firstName, String lastName, String passportId) {
            super("Passport ID already in use. \nCan not create passenger.");
        }
    }