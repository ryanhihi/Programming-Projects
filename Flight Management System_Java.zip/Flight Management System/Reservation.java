package com.example.finalprojectjavasem3;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

public class Reservation{
    // Members
    private int age;
    private double totalFare;
    private String passengerID, flightNum, source, destination, passengerName;
    private LocalDate travelDate;

    // Constructor
    public Reservation(String flightNum, String source, String destination,
                       LocalDate travelDate, String passengerID, String passengerName,
                       int age, double totalFare){
        this.flightNum      = flightNum;
        this.source         = source;
        this.destination    = destination;
        this.travelDate     = travelDate;
        this.passengerID    = passengerID;
        this.passengerName  = passengerName;
        this.age            = age;
        this.totalFare      = totalFare;
    }

    // Getters
    public int getAge() {
        return age;
    }

    public String getPassengerID() {
        return passengerID;
    }

    public double getTotalFare() {
        return totalFare;
    }

    public String getFlightNum() {
        return flightNum;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public LocalDate getTravelDate() {
        return travelDate;
    }


    // Methods
    public static Scene add(List<Flight> flights, List<Passenger> passengers , List<Reservation> reservations, Stage primaryStage, Scene previousScene){
        final Flight[] selectedFlight = new Flight[1];
        final Passenger[] selectedPassenger = new Passenger[1];
        final Scene[] addReservation = new Scene[1];

        // Labels
        Label title             = new Label("Book Reservation");
        Label flightLabel       = new Label("Choose Flight:");
        Label passengerLabel    = new Label("Choose Passenger:");
        Label errorLabel        = new Label();

        // Choose Flight
        AbstractComboBoxBuilder<Flight> flightBuilder = new AbstractComboBoxBuilder<Flight>() {
            @Override
            protected String getStringRepresentation(Flight object) {
                return object == null ? "": object.getFlightNumber();
            }
        };
        ComboBox<Flight> chooseFlight = flightBuilder.createObjectComboBox(flights);
        // collect info
        chooseFlight.setOnAction(e -> {
            selectedFlight[0] = chooseFlight.getSelectionModel().getSelectedItem();
            if (selectedFlight[0] == null)
                errorLabel.setText("Please choose a flight");

            // check flight has space
        });

        // Choose Passenger
        AbstractComboBoxBuilder<Passenger> passengerBuilder = new AbstractComboBoxBuilder<Passenger>() {
            @Override
            protected String getStringRepresentation(Passenger object) {
                return object == null ? "": ("ID: " + object.getPassportID() + ", Name: " + object.getFirstName() + " " + object.getLastName());
            }
        };
        ComboBox<Passenger> choosePassenger = passengerBuilder.createObjectComboBox(passengers);
        // collect info
        choosePassenger.setOnAction(e -> {
            selectedPassenger[0] = choosePassenger.getSelectionModel().getSelectedItem();
            if (selectedPassenger[0] == null)
                errorLabel.setText("Please choose a passenger");

            // check Passenger not on flight
        });

        // Submit button
        Button submit = new Button("BOOK");

        // Validate
        submit.setOnAction(e -> {
            // check passenger not booked on plane
            if(checkOnPlane(reservations, selectedPassenger[0].getPassportID(), selectedFlight[0].getFlightNumber())){
                // Flight has room ?
                if (selectedFlight[0].getMaxPassenger() > selectedFlight[0].getCurrentPassenger())
                    // Add Reservation
                    reservations.add(new Reservation(
                            // flight num
                            selectedFlight[0].getFlightNumber(),
                            // source
                            selectedFlight[0].getSource(),
                            // destination
                            selectedFlight[0].getDestination(),
                            // travelDate
                            selectedFlight[0].getDate(),
                            // pass id
                            selectedPassenger[0].getPassportID(),
                            // pass name
                            (selectedPassenger[0].getFirstName() + " " + selectedPassenger[0].getLastName()),
                            // pass age
                            selectedPassenger[0].getAge(),
                            // total fare
                            selectedFlight[0].getFare()
                    ));

                // add to passCount
                addPassenger(flights, selectedFlight[0]);
                // Clear screen
                chooseFlight.getSelectionModel().clearSelection();
                choosePassenger.getSelectionModel().clearSelection();
                errorLabel.setText("Reservation Added!");
            } else {
                errorLabel.setText("Passenger is already on Flight " + selectedFlight[0].getFlightNumber());
            }
        });

        // Exit button
        Button exit = new Button("Exit");
        exit.setOnAction(e -> primaryStage.setScene(previousScene));

        // Send to new screen
        HBox flightHbox = new HBox(28, flightLabel, chooseFlight);
        flightHbox.setStyle("-fx-alignment: center;");
        HBox passengerHbox = new HBox(5, passengerLabel, choosePassenger);
        passengerHbox.setStyle("-fx-alignment: center;");
        VBox vBox = new VBox(10, title, flightHbox, passengerHbox, submit, errorLabel, exit);
        addReservation[0] = new Scene   (vBox, 500, 450);
        vBox.setStyle                   ("-fx-alignment: center;");
        title.setStyle                  ("-fx-font-size: 26;");
        chooseFlight.setMinSize         (140, 30);
        choosePassenger.setMinSize      (140, 30);
        submit.setMinSize               (80, 30);
        exit.setMinSize                 (80, 30);

        return addReservation[0];
    }

    public static Scene remove(List<Reservation> reservations, Stage primaryStage, Scene previousScene){
        Reservation[] selectedRes = new Reservation[1];
        Scene[] removeReservation = new Scene[1];

        // Labels
        Label title = new Label("Remove Reservation");
        title.setStyle("-fx-font-size: 26;");
        Label resLabel = new Label("Choose Reservation: ");
        resLabel.setMinSize(140, 30);
        Label errorLabel = new Label();
        errorLabel. setMinSize(140, 30);

        // Choose Res combo box
        AbstractComboBoxBuilder<Reservation> resBuilder = new AbstractComboBoxBuilder<Reservation>() {
            @Override
            protected String getStringRepresentation(Reservation object) {
                return object == null ? "" : ("Flight: " + object.getFlightNum() + ", Passenger: " + object.getPassengerName());
            }
        };
        ComboBox<Reservation> reservationComboBox = resBuilder.createObjectComboBox(reservations);
        // collect info
        reservationComboBox.setOnAction(e -> {
            selectedRes[0] = reservationComboBox.getSelectionModel().getSelectedItem();
            if (selectedRes[0] == null)
                errorLabel.setText("Please choose a reservation");
        });

        // Submit button
        Button submit = new Button("Submit");
        submit.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setContentText("Are you sure?");
            alert.showAndWait().ifPresent(r -> {
                if (r == javafx.scene.control.ButtonType.OK) {
                    // remove reservation
                    reservations.remove(selectedRes[0]);
                    reservationComboBox.getItems().setAll(reservations);
                    reservationComboBox.getSelectionModel().clearSelection();
                    errorLabel.setText("Reservation Removed");
                }
            });
        });

        Button exit = new Button("Exit");
        exit.setOnAction(e -> primaryStage.setScene(previousScene));

        // Send to new screen
        HBox hBox = new HBox(0, resLabel, reservationComboBox);
        hBox.setStyle                   ("-fx-alignment: center;");
        HBox bottom = new HBox(10, submit, exit);
        bottom.setStyle                   ("-fx-alignment: center;");
        VBox vBox = new VBox(20);
        vBox.getChildren().addAll(title, hBox, errorLabel, bottom);
        removeReservation[0] = new Scene   (vBox, 500, 450);
        vBox.setStyle                   ("-fx-alignment: center;");
        title.setStyle                  ("-fx-font-size: 26;");
        submit.setMinSize               (80, 30);
        exit.setMinSize             (80, 30);

        return removeReservation[0];
    }

    public static Scene display(List<Reservation> reservations, Stage primaryStage, Scene previousScene){
        Reservation[] selectedRes = new Reservation[1];
        Scene[] displayRes = new Scene[1];

        // Labels
        Label title = new Label("Display Reservation");
        title.setStyle("-fx-font-size: 26;");
        Label chooseRes = new Label("Choose Reservation: ");
        chooseRes.setMinSize(140, 30);
        Label info = new Label(updateInfo(reservations.get(0)));

        // Choose Res combo box
        AbstractComboBoxBuilder<Reservation> resBuilder = new AbstractComboBoxBuilder<Reservation>() {
            @Override
            protected String getStringRepresentation(Reservation object) {
                return object == null ? "" : ("Flight: " + object.getFlightNum() + ", Passenger: " + object.getPassengerName());
            }
        };
        ComboBox<Reservation> reservationComboBox = resBuilder.createObjectComboBox(reservations);
        reservationComboBox.getSelectionModel().selectFirst();
        // collect info
        reservationComboBox.setOnAction(e -> {
            selectedRes[0] = reservationComboBox.getSelectionModel().getSelectedItem();
            if (selectedRes[0] != null)
                info.setText(updateInfo(selectedRes[0]));
        });


        // Create Next and Previous buttons
        Button nextButton = new Button("Next");
        nextButton.setMinSize(80, 30);
        Button prevButton = new Button("Previous");
        prevButton.setMinSize(80, 30);
        nextButton.setOnAction(event -> {
            reservationComboBox.getSelectionModel().select(
                    reservationComboBox.getSelectionModel().getSelectedIndex()
                    + 1
                    + reservationComboBox.getItems().size()
                    % reservationComboBox.getItems().size()
            );
            selectedRes[0] = reservationComboBox.getSelectionModel().getSelectedItem();
            if (selectedRes[0] != null)
                info.setText(updateInfo(selectedRes[0]));
        } );
        prevButton.setOnAction(event -> {
            if ((reservationComboBox.getSelectionModel().getSelectedIndex() - 1 + reservationComboBox.getItems().size() % reservationComboBox.getItems().size()
                ) >= 0){
                reservationComboBox.getSelectionModel().select(
                        reservationComboBox.getSelectionModel().getSelectedIndex()
                                - 1
                                + reservationComboBox.getItems().size()
                                % reservationComboBox.getItems().size()
                );
                selectedRes[0] = reservationComboBox.getSelectionModel().getSelectedItem();
                info.setText(updateInfo(selectedRes[0]));
        }});


        //Menu button
        Button exit = new Button("Exit");
        exit.setMinSize       (80, 30);
        exit.setOnAction(e -> primaryStage.setScene(previousScene));

        // Send to new screen
        HBox hBox = new HBox(10, prevButton, exit, nextButton);
        hBox.setStyle("-fx-alignment: center;");
        VBox vBox = new VBox(10, title, chooseRes, reservationComboBox, info, hBox);
        displayRes[0] = new Scene(vBox, 500, 450);
        vBox.setStyle("-fx-alignment: center;");

        return displayRes[0];
    }

    private static String updateInfo(Reservation reservation){

        return ("Flight Number: "  + reservation.getFlightNum() +
                "\nSource: "            + reservation.getSource() +
                "\nDestination: "       + reservation.getDestination() +
                "\nDate of Travel: "    + reservation.getTravelDate().toString() +
                "\nPassenger Name: "    + reservation.getPassengerName() +
                "\nPassenger Age: "     + reservation.getAge() +
                "\nTotal Fare Amount: $"+ reservation.getTotalFare());
    }


    public static boolean checkOnPlane(List<Reservation> reservations, String passId, String flightId){
        for (Reservation reservation : reservations){
            if(reservation.getPassengerID().equals(passId) && reservation.getFlightNum().equals(flightId))
                return false;
        }
        return true;
    }

    private static void addPassenger(List<Flight> flights, Flight selectedFlight){
        for(Flight flight : flights){
            if (flight == selectedFlight)
                flight.addPassenger();
        }
    }

}
