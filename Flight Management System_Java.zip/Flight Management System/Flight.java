package com.example.finalprojectjavasem3;

// import libraries
import java.time.LocalDate;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

    // Flight Class to store Flight information
// This method is for AirLine company to add flights into the system
    public class Flight {
        // Initialize variables
        public String flightNumber;
        public LocalDate date;
        public String source;
        public String destination;
        public int maxPassenger, currentPassenger;
        public double fare;


        // Constructor
        public Flight(String flightNumber, LocalDate date, String source, String destination, int maxPassenger, double fare) {
            this.flightNumber = flightNumber;
            this.date = date;
            this.source = source;
            this.destination = destination;
            this.maxPassenger = maxPassenger;
            this.fare = fare;
        }

        public String getFlightNumber() {
            return flightNumber;
        }

        public LocalDate getDate() {
            return date;
        }

        public String getSource() {
            return source;
        }

        public String getDestination() {
            return destination;
        }

        public int getMaxPassenger() {
            return maxPassenger;
        }

        public int getCurrentPassenger() {
            return currentPassenger;
        }

        public double getFare() {
            return fare;
        }

        public void addPassenger(){
            this.currentPassenger++;
        }

        //Method to add Flight into the system
        //Before add flights into the system we need to validate if the flight number is unique
        //Method isFlightNumberUnique
        // Method to check if the flight number is unique
        private static boolean isFlightNumberUnique(List<Flight> flights, String flightNumber) {
            return flights.stream()
                    .noneMatch(flight -> flight.flightNumber.equalsIgnoreCase(flightNumber));
        }


        //Add new Flight into flights array using isFlightNumberUnique validation
        // Method to add Flight into the system
        public static String addFlight(List<Flight> flights, String flightNumber, LocalDate date, String source,
                                     String destination, int maxPassenger, double fare) {
            try {
                if (!isFlightNumberUnique(flights, flightNumber)) {
                    throw new DuplicateFlightException("Flight number already exists. \nCannot add duplicate flight.");
                }
                Flight newFlight = new Flight(flightNumber, date, source, destination, maxPassenger, fare);
                flights.add(newFlight);
                 return ("Flight added successfully.");
            } catch (DuplicateFlightException e) {
                return ("Error: " + e.getMessage());
            }
        }

        public static Scene add(List<Flight> flights, Stage primaryStage, Scene previousScene){
            Scene[] scene = new Scene[1];

            // Labels
            Label title = new Label("Add Flight");
            title.setStyle("-fx-font-size: 26;");
            Label flightNumLabel = new Label("Flight Number:");
            flightNumLabel.setMinSize(140, 30);
            Label dateLabel = new Label("Date:");
            dateLabel.setMinSize(140, 30);
            Label sourceLabel = new Label("Source:");
            sourceLabel.setMinSize(140, 30);
            Label destinationLabel = new Label("Destination:");
            destinationLabel.setMinSize(140, 30);
            Label maxPassLabel = new Label("Max Capacity:");
            maxPassLabel.setMinSize(140, 30);
            Label fareLabel = new Label("Fare:");
            fareLabel.setMinSize(140, 30);
            final Label errorLabel = new Label();
            errorLabel.setMinSize(140, 30);

            // Text Fields
            TextField flightNumTF = new TextField();
            flightNumTF.setMinSize(140,30);
            TextField sourceTF = new TextField();
            sourceTF.setMinSize(140,30);
            TextField destinationTF = new TextField();
            destinationTF.setMinSize(140,30);
            TextField fareTF = new TextField();
            fareTF.setMinSize(140,30);

            // Fare spinner
            Spinner<Integer> maxPassSpinner = new Spinner<>(10, 300, 50);
            maxPassSpinner.setMinSize(140, 30);

            // Date calendar
            DatePicker date = new DatePicker();
            date.setMinSize(140,30);

            // Submit Button
            Button submit = new Button("Submit");
            submit.setMinSize(80,30);
            submit.setOnAction(e -> {
                try {
                    // make sure fare is double
                    double fare = Double.parseDouble(fareTF.getText());

                    // is a number
                    maxPassSpinner.getEditor().textProperty().addListener((observable, oldValue, newValue) -> {
                        try {
                            // Try parsing the entered text as an integer
                            Integer.parseInt(newValue);

                            // make sure date is future
                            if(date.getValue().isAfter(LocalDate.now())){
                                if (!flightNumTF.getText().isEmpty() && !sourceTF.getText().isEmpty()
                                        && !destinationTF.getText().isEmpty()) {
                                    // send to add flight
                                    errorLabel.setText(addFlight(
                                            flights,
                                            flightNumTF.getText(),
                                            date.getValue(),
                                            sourceTF.getText(),
                                            destinationTF.getText(),
                                            maxPassSpinner.getValue(),
                                            fare));

                                    // clear screen
                                    flightNumTF.clear();
                                    dateLabel.setText("Date:");
                                    sourceTF.clear();
                                    destinationTF.clear();
                                    fareTF.clear();
                                }
                            } else
                                errorLabel.setText("Please choose a future date.");
                        } catch (NumberFormatException error) {
                            // If parsing fails, set the old value
                            maxPassSpinner.getEditor().setText(oldValue);
                            errorLabel.setText("Please enter a number for Max Passengers.");
                        }
                    });
                } catch (NumberFormatException error){
                    errorLabel.setText("Please enter a number for Fare.");
                }
            });

            // Exit button
            Button exit   = new Button("Exit");
            exit.setMinSize(80, 30);
            exit.setOnAction(e -> primaryStage.setScene(previousScene));

            HBox flightNumHbox = new HBox(0, flightNumLabel, flightNumTF);
            flightNumHbox.setStyle("-fx-alignment: center;");
            HBox dateBox = new HBox(0, dateLabel, date);
            dateBox.setStyle("-fx-alignment: center;");
            HBox sourceHbox = new HBox(0, sourceLabel, sourceTF);
            sourceHbox.setStyle("-fx-alignment: center;");
            HBox destinationHbox = new HBox(0, destinationLabel, destinationTF);
            destinationHbox.setStyle("-fx-alignment: center;");
            HBox maxPassHbox = new HBox(0, maxPassLabel, maxPassSpinner);
            maxPassHbox.setStyle("-fx-alignment: center;");
            HBox fareHbox = new HBox(0, fareLabel, fareTF);
            fareHbox.setStyle("-fx-alignment: center;");
            HBox bottom = new HBox(10, submit, exit);
            bottom.setStyle("-fx-alignment: center;");
            VBox vBox = new VBox(10, title, flightNumHbox, dateBox, sourceHbox, destinationHbox, maxPassHbox, fareHbox, errorLabel, bottom);
            vBox.setStyle("-fx-alignment: center;");
            scene[0] = new Scene(vBox, 500, 450);

            return scene[0];
        }

        // Method to remove a flight from the system
        public static String removeFlight(List<Flight> flights, List<Reservation> reservations, String flightNumber) {
            try {
                for (Flight flight : flights) {
                    if (flight.flightNumber.equalsIgnoreCase(flightNumber)) {
                        flights.remove(flight);

                        reservations.removeIf(reservation -> reservation.getFlightNum().equals(flightNumber));

                        return "Flight and related bookings removed successfully";
                    }
                }

                throw new FlightNotFoundException("Flight not found.");
            } catch (FlightNotFoundException e) {
                return ("Error: " + e.getMessage());
            }
        }

        public static Scene remove(List<Flight> flights, List<Reservation> reservations, Stage primaryStage, Scene previousScene){
            final Flight[] selected = new Flight[1];
            Scene[] scene = new Scene[1];

            // Labels
            Label title = new Label("Remove Flight");
            title.setStyle("-fx-font-size: 26;");
            final Label errorLabel = new Label();
            errorLabel.setMinSize(140, 30);

            // ComboBox
            AbstractComboBoxBuilder<Flight> builder = new AbstractComboBoxBuilder<Flight>() {
                @Override
                protected String getStringRepresentation(Flight object) {
                    return object == null ? "" : ("Flight Number: " + object.getFlightNumber() + ", From: " + object.getSource() + ", To: " + object.getDestination());
                }
            };
            ComboBox<Flight> comboBox = builder.createObjectComboBox(flights);
            comboBox.getSelectionModel().selectFirst();

            // Submit Button
            Button submit = new Button("Submit");
            submit.setMinSize(80,30);
            submit.setOnAction(e -> {
                selected[0] = comboBox.getSelectionModel().getSelectedItem();
                if (selected[0] != null){
                    errorLabel.setText(removeFlight(flights, reservations, selected[0].getFlightNumber()));
                    if (errorLabel.getText().equals("Flight and related bookings removed successfully")) {
                        comboBox.getSelectionModel().clearSelection();
                        comboBox.getItems().addAll(flights);
                    }
                } else
                    errorLabel.setText("Please choose a flight.");
            });

            // Exit button
            Button exit   = new Button("Exit");
            exit.setMinSize(80, 30);
            exit.setOnAction(e -> primaryStage.setScene(previousScene));

            HBox bottom = new HBox(10, submit, exit);
            bottom.setStyle("-fx-alignment: center;");
            VBox vBox = new VBox(10, title, comboBox, errorLabel, bottom);
            vBox.setStyle("-fx-alignment: center;");
            scene[0] = new Scene(vBox, 500, 450);

            return scene[0];
        }

        // Method to update the destination of an existing flight using validateCityName() method called from Validation Class
        // Inside the Flight class
        public static void updateFlight(List<Flight> flights, String flightNumber, String newDestination, Label statusLabel)
                throws FlightNotFoundException, InvalidInputException {
            boolean flightFound = false;
            for (Flight flight : flights) {
                if (flight.flightNumber.equalsIgnoreCase(flightNumber)) {
                    statusLabel.setText("Current destination: " + flight.destination);

                    flight.destination = newDestination;
                    statusLabel.setText("Destination updated to: " + newDestination);
                    flightFound = true;
                    break;
                }
            }

            if (!flightFound) {
                throw new FlightNotFoundException("Flight not found.");
            }
        }

        public static Scene display(List<Flight> flights, Stage primaryStage, Scene previousScene){
            Flight[] selected = new Flight[1];
            Scene[] scene = new Scene[1];

            // Labels
            Label title = new Label("Display Flights");
            title.setStyle("-fx-font-size: 26;");
            Label flightLabel = new Label("Choose Flight: ");
            flightLabel.setMinSize(140, 30);
            Label info = new Label(flights.get(0).updateInfo());

            //Combo box
            AbstractComboBoxBuilder<Flight> builder = new AbstractComboBoxBuilder<Flight>() {
                @Override
                protected String getStringRepresentation(Flight object) {
                    return object == null ? "" : ("Flight Number: " + object.getFlightNumber() + ", From: " + object.getSource() + ", To: " + object.getDestination());
                }
            };
            ComboBox<Flight> comboBox = builder.createObjectComboBox(flights);
            comboBox.getSelectionModel().selectFirst();
            comboBox.setOnAction(e -> {
                selected[0] = comboBox.getSelectionModel().getSelectedItem();
                if (selected[0] != null){
                    info.setText(selected[0].updateInfo());
                }
            });

            // Next
            Button nextButton = new Button("Next");
            nextButton.setMinSize(80, 30);
            nextButton.setOnAction(e -> {
                comboBox.getSelectionModel().select(
                        comboBox.getSelectionModel().getSelectedIndex()
                                + 1
                                + comboBox.getItems().size()
                                % comboBox.getItems().size()
                );
                selected[0] = comboBox.getSelectionModel().getSelectedItem();
                if (selected[0] != null){
                    info.setText(selected[0].updateInfo());
                }
            });

            // Previous
            Button prevButton = new Button("Previous");
            prevButton.setMinSize(80, 30);
            prevButton.setOnAction(e -> {
                if((comboBox.getSelectionModel().getSelectedIndex() - 1 + comboBox.getItems().size() % comboBox.getItems().size()
                ) >= 0){
                    comboBox.getSelectionModel().select(
                            comboBox.getSelectionModel().getSelectedIndex()
                                    - 1
                                    + comboBox.getItems().size()
                                    % comboBox.getItems().size()
                    );
                    selected[0] = comboBox.getSelectionModel().getSelectedItem();
                    info.setText(selected[0].updateInfo());
                }
            });

            // Exit
            Button exit = new Button("Exit");
            exit.setMinSize(80, 30);
            exit.setOnAction(e -> primaryStage.setScene(previousScene));

            HBox hBox = new HBox(10, prevButton, exit, nextButton);
            hBox.setStyle("-fx-alignment: center;");
            VBox vBox = new VBox(10, title, flightLabel, comboBox, info, hBox);
            vBox.setStyle("-fx-alignment: center;");
            scene[0] = new Scene(vBox, 500, 450);

            return scene[0];
        }

        public String updateInfo(){ // prints the object info on the screen
            return ("Flight Number: " + flightNumber +
                    "\nDate: " + date +
                    "\nSource: " + source +
                    "\nDestination: " + destination +
                    "\nMax Capacity: " + maxPassenger +
                    "\nCurrent Capacity: " + currentPassenger +
                    "\nFare: " + fare);
        }
    }



    class DuplicateFlightException extends Exception {
        public DuplicateFlightException(String message) {
            super(message);
        }
    }
    class FlightNotFoundException extends Exception {
        public FlightNotFoundException(String message) {
            super(message);
        }
    }


    class InvalidInputException extends Exception {
        public InvalidInputException(String message) {
            super(message);
        }
    }